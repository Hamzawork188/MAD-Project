plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.google.gms.google.services)
}

android {
    namespace = "com.example.foodpandaproject"
    compileSdk = 36 // Latest API for your new libraries

    defaultConfig {
        applicationId = "com.example.foodpandaproject"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    packaging {
        jniLibs {
            // Android 15+ (16 KB) support ke liye mandatory
            useLegacyPackaging = false
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            // Fixed duplicate files error for Google Auth
            pickFirsts += "META-INF/DEPENDENCIES"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Standard UI Libraries
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // 🔥 Firebase (BoM use karein taake versions ka jhagra na ho)
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.auth)
    implementation(libs.firebase.database)
    implementation(libs.firebase.firestore)
    implementation("com.google.firebase:firebase-messaging")

    // 🔥 Google Auth & FCM v1 Dependencies
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("com.google.auth:google-auth-library-oauth2-http:1.19.0") {
        exclude(group = "org.apache.httpcomponents", module = "httpclient")
    }
    implementation(libs.credentials)
    implementation(libs.credentials.play.services.auth)
    implementation(libs.googleid)

    // 🔥 QR Scanner Fix
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.4.1")

    // 🔥 Volley for Networking
    implementation("com.android.volley:volley:1.2.1")

    // Others
    implementation("com.google.android.gms:play-services-ads:24.9.0")
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}