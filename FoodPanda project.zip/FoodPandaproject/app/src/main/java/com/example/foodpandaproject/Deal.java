package com.example.foodpandaproject;
public class Deal {
    String title;
    String subtitle;
    int imageResId;
    int backgroundColorResId;

    public Deal(String title, String subtitle, int imageResId, int backgroundColorResId) {
        this.title = title;
        this.subtitle = subtitle;
        this.imageResId = imageResId;
        this.backgroundColorResId = backgroundColorResId;
    }

    public String getTitle() { return title; }
    public String getSubtitle() { return subtitle; }
    public int getImageResId() { return imageResId; }
    public int getBackgroundColorResId() { return backgroundColorResId; }
}