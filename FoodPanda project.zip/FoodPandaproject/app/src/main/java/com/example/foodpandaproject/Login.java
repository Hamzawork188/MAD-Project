package com.example.foodpandaproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;

/**
 * Login Activity handling Email, Google, and navigation to Phone Login/SignUp.
 * Includes automatic Login Notification triggering.
 */
public class Login extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private GoogleSignInClient mGoogleSignInClient;

    private EditText emailET, passwordET;
    private Button loginBtn, googleBtn, phoneBtn;
    private TextView tvSignUp, tvForgot;

    private final String appId = "foodpandaandroid";
    private static final int RC_SIGN_IN = 9001;
    private static final int NOTIFY_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 1. Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // 2. Bind UI Elements
        emailET = findViewById(R.id.email);
        passwordET = findViewById(R.id.password);
        loginBtn = findViewById(R.id.btnLogin);
        googleBtn = findViewById(R.id.btnGoogleLogin);
        phoneBtn = findViewById(R.id.btnPhoneLogin);
        tvSignUp = findViewById(R.id.SignUp);
        tvForgot = findViewById(R.id.tvForgot);

        // 3. Request Notification Permissions (Android 13+)
        checkNotificationPermission();

        // 4. Configure Google Sign-In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // --- Listeners ---

        // Email Login
        loginBtn.setOnClickListener(v -> {
            String email = emailET.getText().toString().trim();
            String pass = passwordET.getText().toString().trim();
            if (email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }
            loginUser(email, pass);
        });

        // Google Login
        googleBtn.setOnClickListener(v -> {
            Intent signInIntent = mGoogleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        });

        phoneBtn.setOnClickListener(v -> {
            startActivity(new Intent(Login.this, PhoneAuthActivity.class));
        });

        // Shift to Sign Up
        tvSignUp.setOnClickListener(v -> {
            startActivity(new Intent(Login.this, SignUp.class));
        });

        // Forgot Password
        tvForgot.setOnClickListener(v -> {
            startActivity(new Intent(Login.this, ForgotPassword.class));
        });
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFY_PERMISSION_CODE);
            }
        }
    }

    private void loginUser(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> fetchNameAndNotify(mAuth.getUid()))
                .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                Log.e("LOGIN", "Google sign in failed", e);
            }
        }
    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                fetchNameAndNotify(mAuth.getUid());
            } else {
                Toast.makeText(this, "Google Auth Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Requirement: Fetch User Data from Firestore and Send Login Notification
     */
    private void fetchNameAndNotify(String uid) {
        db.collection("artifacts").document(appId)
                .collection("public").document("data")
                .collection("users").document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        String name = doc.getString("name");
                        String token = doc.getString("fcmToken");

                        // Trigger the welcome notification
                        if (token != null && !token.isEmpty()) {
                            FCMHelper.sendNotification(this, token,
                                    "Welcome Back!",
                                    "You have logged in as " + (name != null ? name : "User"));
                        }
                    }
                    // Move to the next screen
                    startActivity(new Intent(Login.this, Mainscreen.class));
                    finish();
                })
                .addOnFailureListener(e -> {
                    // Fail gracefully by moving to MainScreen anyway
                    startActivity(new Intent(Login.this, Mainscreen.class));
                    finish();
                });
    }
}