package com.example.foodpandaproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class SignUp extends AppCompatActivity {
    private EditText etName, etEmail, etPassword, etPhone;
    private Button btnSignUp, btnGoogle, btnPhone;
    private TextView tvLogin;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private GoogleSignInClient mGoogleSignInClient;

    private static final int RC_SIGN_IN = 9001;
    // ZAROORI: Ye appId har file (Mainscreen, UserList, Chat) mein bilkul SAME honi chahiye
    private final String appId = "foodpandaandroid";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // UI Binding
        etName = findViewById(R.id.name);
        etEmail = findViewById(R.id.email);
        etPhone = findViewById(R.id.phone);
        etPassword = findViewById(R.id.password);
        btnSignUp = findViewById(R.id.btnSignUp);
        btnGoogle = findViewById(R.id.btnGoogleSignUp);
        btnPhone = findViewById(R.id.btnPhoneSignUp);
        tvLogin = findViewById(R.id.tvLog);

        // Google Sign In Configuration
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // 1. Email Sign Up Listener
        btnSignUp.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();
            String name = etName.getText().toString().trim();

            if(email.isEmpty() || pass.isEmpty() || name.isEmpty()) {
                Toast.makeText(this, "Sari fields fill karein!", Toast.LENGTH_SHORT).show();
                return;
            }

            mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    saveUserToFirestore(name, email);
                } else {
                    Toast.makeText(this, "Signup Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });

        // 2. Google Sign Up Listener (FIXED: Ab hamesha account picker khulega)
        btnGoogle.setOnClickListener(v -> {
            // Pehle sign out karein taake hamesha account pooche
            mGoogleSignInClient.signOut().addOnCompleteListener(task -> {
                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);
            });
        });

        // 3. Phone Sign Up Listener
        btnPhone.setOnClickListener(v -> {
            String phone = etPhone.getText().toString().trim();
            String name = etName.getText().toString().trim();

            if (phone.isEmpty() || !phone.startsWith("+")) {
                Toast.makeText(this, "Phone number + ke saath enter karein (e.g. +92)", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(SignUp.this, PhoneAuthActivity.class);
            intent.putExtra("phoneNumber", phone);
            intent.putExtra("name", name);
            startActivity(intent);
        });

        tvLogin.setOnClickListener(v ->{
            startActivity(new Intent(SignUp.this, Login.class));
            finish();
                }

        );
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                Toast.makeText(this, "Google Error: " + e.getStatusCode(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        mAuth.signInWithCredential(credential).addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                // Google se login ke baad bhi Firestore mein save karna zaroori hai chat list ke liye
                saveUserToFirestore(acct.getDisplayName(), acct.getEmail());
            } else {
                Toast.makeText(this, "Google Auth Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveUserToFirestore(String name, String email) {
        if(mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        Map<String, Object> user = new HashMap<>();
        user.put("name", name != null ? name : "User");
        user.put("email", email != null ? email : "");
        user.put("uid", uid);

        // STEP 1: Private Profile (artifacts -> appId -> users -> uid -> profile -> data)
        db.collection("artifacts").document(appId)
                .collection("users").document(uid)
                .collection("profile").document("data")
                .set(user);

        // STEP 2: Public Chat List (artifacts -> appId -> public -> data -> users -> uid)
        // ISI PATH se UserListActivity data uthayegi
        db.collection("artifacts").document(appId)
                .collection("public").document("data")
                .collection("users").document(uid)
                .set(user)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Welcome " + name, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(this, Mainscreen.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Firestore Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}