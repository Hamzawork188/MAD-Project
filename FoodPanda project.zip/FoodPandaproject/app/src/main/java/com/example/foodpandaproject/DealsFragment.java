package com.example.foodpandaproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DealsFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_deals, container, false);
        recyclerView = view.findViewById(R.id.recycler_view_deals);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        loadDealProducts();
        adapter = new ProductAdapter(getContext(), productList);
        recyclerView.setAdapter(adapter);

        return view;
    }
    private void loadDealProducts() {
        productList = new ArrayList<>();
        productList.add(new Product("3 Zinger Burgers", "3 Zingers in just 750", R.drawable.burger3));
        productList.add(new Product("Large Pizza Deal", "1 Large Pizza + 1 Ltr Drink in just 2450", R.drawable.pizza2));
        productList.add(new Product("Family Biryani Deal", "2 Boxes of Chicken Biryani in just 1000", R.drawable.biryani2));
    }
}