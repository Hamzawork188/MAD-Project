package com.example.foodpandaproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HealthyFragment extends Fragment {
    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_healthy, container, false);
        recyclerView = view.findViewById(R.id.recycler_view_healthy);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        loadHealthyProducts();

        adapter = new ProductAdapter(getContext(), productList);
        recyclerView.setAdapter(adapter);

        return view;
    }
    private void loadHealthyProducts() {
        productList = new ArrayList<>();
        productList.add(new Product("Caesar Salad", "Fresh salad with chicken", R.drawable.salad));
        productList.add(new Product("Fruit Chaat", "Mixed fruit bowl", R.drawable.fruit));
        productList.add(new Product("Chicken Sandwich", "Brown bread sandwich", R.drawable.sandwich));
    }
}