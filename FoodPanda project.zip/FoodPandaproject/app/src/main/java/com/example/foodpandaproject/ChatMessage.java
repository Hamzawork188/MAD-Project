package com.example.foodpandaproject;


public class ChatMessage {
    private String text;
    private boolean isUser;
    private String senderId;
    private String receiverId;
    private long timestamp;

    // Default constructor for Firebase
    public ChatMessage() {}

    // Constructor for AI Chatbot
    public ChatMessage(String text, boolean isUser) {
        this.text = text;
        this.isUser = isUser;
    }

    // Constructor for One-to-One Chat
    public ChatMessage(String senderId, String receiverId, String text, long timestamp) {
        this.senderId = senderId;
        this.receiverId = receiverId;
        this.text = text;
        this.timestamp = timestamp;
    }

    public String getText() { return text; }
    public boolean isUser() { return isUser; }
    public String getSenderId() { return senderId; }
    public String getReceiverId() { return receiverId; }
    public long getTimestamp() { return timestamp; }
}