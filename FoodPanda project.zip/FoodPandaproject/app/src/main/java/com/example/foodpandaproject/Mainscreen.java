package com.example.foodpandaproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class Mainscreen extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private Button btnNavHome, btnNavCart, btnCamera;
    private NavigationView navigationView;
    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainscreen);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // --- AdMob Initialization ---
        MobileAds.initialize(this, initializationStatus -> { });

        mAdView = findViewById(R.id.adView);
        if (mAdView != null) {
            mAdView.setAdListener(new AdListener() {
                @Override
                public void onAdClicked() {
                    Toast.makeText(Mainscreen.this, "Ad Clicked!", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAdClosed() {
                    Toast.makeText(Mainscreen.this, "Ad Closed! Returning to app.", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError adError) {
                    Toast.makeText(Mainscreen.this, "Failed to load ad", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAdImpression() { }

                @Override
                public void onAdLoaded() {
                    Toast.makeText(Mainscreen.this, "Ad Loaded!", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAdOpened() {
                    Toast.makeText(Mainscreen.this, "Ad Opened!", Toast.LENGTH_SHORT).show();
                }
            });

            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        }

        // --- UI Setup ---
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        btnNavHome = findViewById(R.id.btn_nav_home);
        btnNavCart = findViewById(R.id.btn_nav_cart);
        btnCamera = findViewById(R.id.btn_nav_camera_footer);

        // Footer Click Listeners
        btnNavHome.setOnClickListener(v -> replaceFragment(new HomeFragment()));
        btnNavCart.setOnClickListener(v -> replaceFragment(new CartFragment()));

        btnCamera.setOnClickListener(v -> {
            // Updated to QRScannerActivity to match the project files
            Intent intent = new Intent(Mainscreen.this, QRScanner.class);
            startActivity(intent);
        });

        // --- Back Press Logic for Drawer ---
        final OnBackPressedCallback onBackPressedCallback = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
            }
        };
        getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                onBackPressedCallback.setEnabled(true);
            }
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                onBackPressedCallback.setEnabled(false);
            }
        };

        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            replaceFragment(new HomeFragment());
            navigationView.setCheckedItem(R.id.nav_home);
        }
    }

    /**
     * Requirement: Cleanup AdMob resources when activity is destroyed
     */
    public void destroyBanner() {
        if (mAdView != null) {
            View parentView = (View) mAdView.getParent();
            if (parentView instanceof ViewGroup) {
                ((ViewGroup) parentView).removeView(mAdView);
            }
            mAdView.destroy();
            mAdView = null;
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.nav_home) {
            replaceFragment(new HomeFragment());
        } else if (itemId == R.id.nav_deals) {
            replaceFragment(new DealsFragment());
        } else if (itemId == R.id.nav_healthy) {
            replaceFragment(new HealthyFragment());
        } else if (itemId == R.id.nav_drinks) {
            replaceFragment(new DrinksFragment());
        } else if (itemId == R.id.nav_profile) {
            startActivity(new Intent(Mainscreen.this, DataEntryActivity.class));
        } else if (itemId == R.id.nav_help) {
            startActivity(new Intent(Mainscreen.this, Chatbot.class));
        } else if (itemId == R.id.nav_logout) {
            performLogout();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void performLogout() {
        FirebaseAuth.getInstance().signOut();
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Mainscreen.this, Login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, fragment);
        fragmentTransaction.commit();
    }

    @Override
    protected void onPause() {
        if (mAdView != null) mAdView.pause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAdView != null) mAdView.resume();
    }

    @Override
    protected void onDestroy() {
        destroyBanner();
        super.onDestroy();
    }
}