package com.example.foodpandaproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DataDisplayActivity extends AppCompatActivity {

    TextView tvShowUsername, tvShowAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        tvShowUsername = findViewById(R.id.tv_show_username);
        tvShowAge = findViewById(R.id.tv_show_age);

        Intent intent = getIntent();
        if (intent != null) {
            String username = intent.getStringExtra("EXTRA_USERNAME");
            int age = intent.getIntExtra("EXTRA_AGE", 0); // 0 is default value
            String dob = intent.getStringExtra("EXTRA_DOB");

            tvShowUsername.setText("Username: " + username);
            tvShowAge.setText("Age: " + age + " (DOB: " + dob + ")");
        }
    }
}