package com.example.foodpandaproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView dealsRecyclerView;
    private DealAdapter dealAdapter;
    private List<Deal> dealList;

    private CardView cardFoodDelivery;
    private CardView cardPandamart;
    private CardView cardShops;
    private CardView cardDineIn;
    private CardView cardPickUp;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        dealsRecyclerView = view.findViewById(R.id.recycler_view_deals);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        dealsRecyclerView.setLayoutManager(layoutManager);
        loadDailyDeals();
        dealAdapter = new DealAdapter(getContext(), dealList);
        dealsRecyclerView.setAdapter(dealAdapter);
        cardFoodDelivery = view.findViewById(R.id.card_food_delivery);
        cardPandamart = view.findViewById(R.id.card_pandamart);
        cardShops = view.findViewById(R.id.card_shops);
        cardDineIn = view.findViewById(R.id.card_dine_in);
        cardPickUp = view.findViewById(R.id.card_pick_up);

        cardFoodDelivery.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), ProductListActivity.class);
            startActivity(intent);
        });

        View.OnClickListener comingSoonListener = v -> {
            Toast.makeText(getContext(), "Coming Soon!", Toast.LENGTH_SHORT).show();
        };

        cardPandamart.setOnClickListener(comingSoonListener);
        cardShops.setOnClickListener(comingSoonListener);
        cardDineIn.setOnClickListener(comingSoonListener);
        cardPickUp.setOnClickListener(comingSoonListener);

        return view;
    }

    private void loadDailyDeals() {
        dealList = new ArrayList<>();
        dealList.add(new Deal("Home Chef!", "Try something new", R.drawable.food,R.color.deal_pink));
        dealList.add(new Deal("COKE Magic Deals", "Save on combos", R.drawable.burger_coke,R.color.deal_red));
        dealList.add(new Deal("New User?", "50% Off", R.drawable.burger,R.color.deal_blue));
        dealList.add(new Deal("Pizza Time", "Buy 1 Get 1", R.drawable.pizza,R.color.deal_orange));
    }
}