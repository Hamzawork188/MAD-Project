package com.example.foodpandaproject;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Splash2 extends AppCompatActivity {

    TextView welcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash2);

        welcome = findViewById(R.id.tvWelcome);
        String name = getIntent().getStringExtra("name");
        welcome.setText("Welcome " + name + " to Foodpanda");

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(Splash2.this,  Mainscreen.class);
                i.putExtra("name", name);
                startActivity(i);
                finish();
            }
        }, 3000);
    }
}