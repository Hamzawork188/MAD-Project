package com.example.foodpandaproject;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {
    private List<ChatMessage> messageList;

    public ChatAdapter(List<ChatMessage> messageList) {
        this.messageList = messageList;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        ChatMessage chatMessage = messageList.get(position);
        holder.messageText.setText(chatMessage.getMessage());

        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) holder.messageText.getLayoutParams();
        if (chatMessage.isUser()) {
            holder.messageText.setBackgroundResource(android.R.drawable.editbox_dropdown_light_frame);
            params.gravity = Gravity.END;
            holder.messageText.setTextColor(0xFF000000);
        } else {
            holder.messageText.setBackgroundResource(android.R.drawable.editbox_dropdown_dark_frame);
            params.gravity = Gravity.START;
            holder.messageText.setTextColor(0xFFFFFFFF);
        }
        holder.messageText.setLayoutParams(params);
    }

    @Override
    public int getItemCount() { return messageList.size(); }

    static class ChatViewHolder extends RecyclerView.ViewHolder {
        TextView messageText;
        ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.tv_message);
        }
    }
}