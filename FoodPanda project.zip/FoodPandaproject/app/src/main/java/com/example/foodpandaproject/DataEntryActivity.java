package com.example.foodpandaproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class DataEntryActivity extends AppCompatActivity {

    EditText etUsername;
    TextView tvSelectedDate;
    Button btnPickDate, btnSave;

    private String selectedDateString = "";
    private int selectedYear, selectedMonth, selectedDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_entry);

        etUsername = findViewById(R.id.et_username);
        tvSelectedDate = findViewById(R.id.tv_selected_date);
        btnPickDate = findViewById(R.id.btn_pick_date);
        btnSave = findViewById(R.id.btn_save);

        btnPickDate.setOnClickListener(v -> showDatePickerDialog());

        btnSave.setOnClickListener(v -> sendData());
    }

    private void showDatePickerDialog() {

        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year1, monthOfYear, dayOfMonth) -> {

                    selectedYear = year1;
                    selectedMonth = monthOfYear;
                    selectedDay = dayOfMonth;

                    selectedDateString = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year1;
                    tvSelectedDate.setText("Selected Date: " + selectedDateString);
                },
                year, month, day);

        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void sendData() {
        String username = etUsername.getText().toString().trim();

        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedDateString.isEmpty()) {
            Toast.makeText(this, "Please pick your date of birth", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(DataEntryActivity.this, DataDisplayActivity.class);
        intent.putExtra("EXTRA_USERNAME", username);
        intent.putExtra("EXTRA_DOB", selectedDateString);

        int age = calculateAge(selectedYear, selectedMonth, selectedDay);
        intent.putExtra("EXTRA_AGE", age);

        startActivity(intent);
    }

    private int calculateAge(int year, int month, int day) {
        Calendar dob = Calendar.getInstance();
        dob.set(year, month, day);
        Calendar today = Calendar.getInstance();
        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }
        return age;
    }
}