package com.example.foodpandaproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

public class ProductListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        Toolbar toolbar = findViewById(R.id.toolbar_products);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Food Delivery");

        recyclerView = findViewById(R.id.recycler_view_products);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadProducts();

        adapter = new ProductAdapter(this, productList);
        recyclerView.setAdapter(adapter);
    }
    private void loadProducts() {
        productList = new ArrayList<>();
        productList.add(new Product("Beef Burger", "Crispy Beef burger", R.drawable.burger));
        productList.add(new Product("Pepperoni Pizza", "Classic pepperoni pizza", R.drawable.pizza));
        productList.add(new Product("Chicken Sushi", "8-piece sushi roll", R.drawable.sushi));
        productList.add(new Product("Fettuccine Alfredo", "Creamy pasta dish", R.drawable.pasta));
        productList.add(new Product("BBQ Chicken Wings", "6-piece spicy wings", R.drawable.wings));
        productList.add(new Product("Caesar Salad", "Fresh salad with chicken", R.drawable.salad));
        productList.add(new Product("Chocolate Brownie", "Warm dessert", R.drawable.brownie));
        productList.add(new Product("Zinger Burger", "Zinger burger", R.drawable.zinger));
        productList.add(new Product("Chicken Biryani", "Spicy rice dish", R.drawable.biryani));
        productList.add(new Product("Almond Milk", "1 Litre Milk", R.drawable.milk));
        productList.add(new Product("Bread roll", "Fresh bread roll", R.drawable.bread));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}