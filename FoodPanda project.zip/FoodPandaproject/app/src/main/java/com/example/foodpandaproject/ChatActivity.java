package com.example.foodpandaproject;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MessageAdapter adapter;
    private List<ChatMessage> messageList;
    private EditText etInput;
    private ImageButton btnSend;

    private FirebaseFirestore db;
    private String currentUserId;
    private String receiverId; // Intent se aayega
    private final String appId = "foodpandaandroid";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        db = FirebaseFirestore.getInstance();
        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Demo ke liye hardcoded receiverId, real app mein Intent se lein
        receiverId = getIntent().getStringExtra("RECEIVER_ID");
        if (receiverId == null) receiverId = "demo_receiver_id";

        recyclerView = findViewById(R.id.rv_chat);
        etInput = findViewById(R.id.et_chat_input);
        btnSend = findViewById(R.id.btn_chat_send);

        messageList = new ArrayList<>();
        adapter = new MessageAdapter(messageList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        btnSend.setOnClickListener(v -> sendMessage());

        listenForMessages();
    }

    private void sendMessage() {
        String text = etInput.getText().toString().trim();
        if (text.isEmpty()) return;

        Map<String, Object> message = new HashMap<>();
        message.put("senderId", currentUserId);
        message.put("receiverId", receiverId);
        message.put("text", text);
        message.put("timestamp", System.currentTimeMillis());

        // RULE #1: Strict Path Implementation
        db.collection("artifacts").document(appId)
                .collection("public").document("data")
                .collection("messages")
                .add(message)
                .addOnSuccessListener(documentReference -> etInput.setText(""))
                .addOnFailureListener(e -> Toast.makeText(this, "Send Failed", Toast.LENGTH_SHORT).show());
    }

    private void listenForMessages() {
        // RULE #2: Simple query (fetch all messages for this appId and filter in memory)
        db.collection("artifacts").document(appId)
                .collection("public").document("data")
                .collection("messages")
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("Firestore", "Listen failed", error);
                        return;
                    }

                    if (value != null) {
                        for (DocumentChange dc : value.getDocumentChanges()) {
                            if (dc.getType() == DocumentChange.Type.ADDED) {
                                ChatMessage msg = dc.getDocument().toObject(ChatMessage.class);

                                // Filter in memory for this specific conversation
                                if ((msg.getSenderId().equals(currentUserId) && msg.getReceiverId().equals(receiverId)) ||
                                        (msg.getSenderId().equals(receiverId) && msg.getReceiverId().equals(currentUserId))) {

                                    messageList.add(msg);
                                }
                            }
                        }

                        // Requirement #6: Timestamped sorting
                        Collections.sort(messageList, (m1, m2) -> Long.compare(m1.getTimestamp(), m2.getTimestamp()));
                        adapter.notifyDataSetChanged();
                        recyclerView.scrollToPosition(messageList.size() - 1);
                    }
                });
    }
}