package com.example.foodpandaproject;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Requirement #6: Updated ChatActivity with Real-time listener and Notification integration.
 */
public class ChatActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private final String appId = "foodpandaandroid";
    private String currentUserId;
    private String receiverId;
    private String receiverToken;

    private EditText messageInput;
    private ImageButton sendBtn;
    private RecyclerView recyclerView;
    private MessageAdapter adapter;
    private List<ChatMessage> messageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        db = FirebaseFirestore.getInstance();
        
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            currentUserId = currentUser.getUid();
        } else {
            Toast.makeText(this, "Please Login First", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Intent se receiver ki details lena
        receiverId = getIntent().getStringExtra("RECEIVER_ID");
        if (receiverId == null) receiverId = "demo_user";

        // UI components initialize karna - Fixed IDs and Types
        messageInput = findViewById(R.id.et_chat_input);
        sendBtn = findViewById(R.id.btn_chat_send);
        recyclerView = findViewById(R.id.rv_chat);

        // RecyclerView setup
        messageList = new ArrayList<>();
        adapter = new MessageAdapter(messageList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Permissions aur Token setup
        checkNotificationPermission();
        fetchReceiverToken();

        // Messages ko real-time listen karna
        listenForMessages();

        sendBtn.setOnClickListener(v -> {
            String text = messageInput.getText().toString().trim();
            if (!text.isEmpty()) {
                sendMessage(text);
            }
        });
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    private void fetchReceiverToken() {
        db.collection("artifacts").document(appId)
                .collection("public").document("data")
                .collection("users").document(receiverId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        receiverToken = documentSnapshot.getString("fcmToken");
                    }
                })
                .addOnFailureListener(e -> Log.e("ChatActivity", "Error fetching token", e));
    }

    private void sendMessage(String text) {
        Map<String, Object> message = new HashMap<>();
        message.put("senderId", currentUserId);
        message.put("receiverId", receiverId);
        message.put("text", text);
        message.put("timestamp", System.currentTimeMillis());

        db.collection("artifacts").document(appId)
                .collection("public").document("data")
                .collection("messages")
                .add(message)
                .addOnSuccessListener(documentReference -> {
                    messageInput.setText("");

                    // Notification bhejna agar token mil gaya ho
                    if (receiverToken != null && !receiverToken.isEmpty()) {
                        Log.d("ChatActivity", "Sending notification to: " + receiverToken);
                        FCMHelper.sendNotification(this, receiverToken, "Naya Message!", text);
                    } else {
                        Log.e("ChatActivity", "Receiver token not found! Notification skipped.");
                        fetchReceiverToken();
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to send", Toast.LENGTH_SHORT).show());
    }

    private void listenForMessages() {
        db.collection("artifacts").document(appId)
                .collection("public").document("data")
                .collection("messages")
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("ChatActivity", "Listen failed", error);
                        return;
                    }

                    if (value != null) {
                        for (DocumentChange dc : value.getDocumentChanges()) {
                            if (dc.getType() == DocumentChange.Type.ADDED) {
                                ChatMessage msg = dc.getDocument().toObject(ChatMessage.class);

                                // Sirf is specific conversation ke messages filter karna
                                if (msg.getSenderId() != null && msg.getReceiverId() != null) {
                                    if ((msg.getSenderId().equals(currentUserId) && msg.getReceiverId().equals(receiverId)) ||
                                            (msg.getSenderId().equals(receiverId) && msg.getReceiverId().equals(currentUserId))) {

                                        messageList.add(msg);
                                    }
                                }
                            }
                        }

                        // Timestamps ke mutabiq sort karna
                        Collections.sort(messageList, (m1, m2) -> Long.compare(m1.getTimestamp(), m2.getTimestamp()));
                        adapter.notifyDataSetChanged();
                        if (!messageList.isEmpty()) {
                            recyclerView.scrollToPosition(messageList.size() - 1);
                        }
                    }
                });
    }
}