package com.example.foodpandaproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DealAdapter extends RecyclerView.Adapter<DealAdapter.DealViewHolder> {

    private Context context;
    private List<Deal> dealList;
    private CartManager cartManager;

    public DealAdapter(Context context, List<Deal> dealList) {
        this.context = context;
        this.dealList = dealList;
        this.cartManager = CartManager.getInstance();
    }

    @NonNull
    @Override
    public DealViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_deal_card, parent, false);
        return new DealViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DealViewHolder holder, int position) {
        Deal deal = dealList.get(position);

        holder.dealTitle.setText(deal.getTitle());
        holder.dealSubtitle.setText(deal.getSubtitle());
        holder.dealImage.setImageResource(deal.getImageResId());

        int color = ContextCompat.getColor(context, deal.getBackgroundColorResId());
        holder.dealBackground.setBackgroundColor(color);

        holder.dealCard.setOnClickListener(v -> {
            Toast.makeText(context, "Clicked on " + deal.getTitle(), Toast.LENGTH_SHORT).show();
        });

        holder.btnAddToCart.setOnClickListener(v -> {
            Product product = new Product(deal.getTitle(), deal.getSubtitle(), deal.getImageResId());
            cartManager.addProduct(product);
            Toast.makeText(context, deal.getTitle() + " added to cart", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return dealList.size();
    }

    class DealViewHolder extends RecyclerView.ViewHolder {

        CardView dealCard;
        RelativeLayout dealBackground;
        TextView dealTitle;
        TextView dealSubtitle;
        ImageView dealImage;
        Button btnAddToCart;

        public DealViewHolder(@NonNull View itemView) {
            super(itemView);
            dealCard = itemView.findViewById(R.id.deal_card);
            dealBackground = itemView.findViewById(R.id.deal_background);
            dealTitle = itemView.findViewById(R.id.deal_title);
            dealSubtitle = itemView.findViewById(R.id.deal_subtitle);
            dealImage = itemView.findViewById(R.id.deal_image);
            btnAddToCart = itemView.findViewById(R.id.btn_deal_add_to_cart);
        }
    }
}