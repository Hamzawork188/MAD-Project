package com.example.foodpandaproject;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Chatbot extends AppCompatActivity {
    private EditText messageEditText;
    private ImageButton sendButton;
    private LinearLayout chatContainer;
    private ScrollView scrollView;
    private RequestQueue requestQueue;

    // Fixed Endpoint with new API Key and Gemini 2.5 Flash
    private String getEndpoint() {
        String apiKey = "AIzaSyDg0tSOowJxa3UKOnOZEPVZjOrJn2FIg6k";
        return "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        messageEditText = findViewById(R.id.message_edit_text);
        sendButton = findViewById(R.id.send_button);
        chatContainer = findViewById(R.id.chat_container);
        scrollView = findViewById(R.id.chat_scroll_view);

        requestQueue = Volley.newRequestQueue(this);

        sendButton.setOnClickListener(v -> {
            String userMessage = messageEditText.getText().toString().trim();
            if (userMessage.isEmpty()) {
                Toast.makeText(Chatbot.this, "Please enter a message", Toast.LENGTH_SHORT).show();
                return;
            }

            displayMessage(userMessage, R.drawable.chat_bubble_user);
            messageEditText.setText("");

            try {
                JSONObject part = new JSONObject();
                part.put("text", userMessage);

                JSONObject content = new JSONObject();
                content.put("parts", new JSONArray().put(part));

                JSONObject requestBody = new JSONObject();
                requestBody.put("contents", new JSONArray().put(content));

                sendMessageToAPI(requestBody);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    private void sendMessageToAPI(JSONObject requestBody) {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.POST,
                getEndpoint(),
                requestBody,
                response -> {
                    try {
                        JSONArray candidates = response.getJSONArray("candidates");
                        JSONObject firstCandidate = candidates.getJSONObject(0);
                        JSONArray parts = firstCandidate.getJSONObject("content").getJSONArray("parts");
                        String aiResponse = parts.getJSONObject(0).getString("text");

                        displayMessage(aiResponse, R.drawable.chat_bubble_chatbot);
                    } catch (JSONException e) {
                        Log.e("Chatbot", "Parsing error: " + e.getMessage());
                    }
                },
                error -> {
                    if (error.networkResponse != null) {
                        String errorData = new String(error.networkResponse.data);
                        Log.e("API_ERROR", "Status: " + error.networkResponse.statusCode + " Body: " + errorData);
                        Toast.makeText(Chatbot.this, "Error " + error.networkResponse.statusCode, Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(Chatbot.this, "Connection Error", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(30000, 0, 1f));
        requestQueue.add(jsonObjectRequest);
    }

    @SuppressLint("ResourceAsColor")
    private void displayMessage(String message, int backgroundResource) {
        TextView messageTextView = new TextView(this);
        messageTextView.setText(message);
        messageTextView.setTextSize(16);
        messageTextView.setTextColor(android.graphics.Color.BLACK);
        
        if (backgroundResource == R.drawable.chat_bubble_user) {
            messageTextView.setTextColor(android.graphics.Color.WHITE);
        }
        
        messageTextView.setBackgroundResource(backgroundResource);
        messageTextView.setPadding(30, 20, 30, 20);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        layoutParams.setMargins(0, 20, 0, 0);

        if (backgroundResource == R.drawable.chat_bubble_user) {
            layoutParams.gravity = android.view.Gravity.END;
        } else {
            layoutParams.gravity = android.view.Gravity.START;
        }

        messageTextView.setLayoutParams(layoutParams);
        chatContainer.addView(messageTextView);

        if (scrollView != null) {
            scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
        }
    }
}