package com.example.foodpandaproject;

import android.content.Context;
import android.util.Log;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.auth.oauth2.GoogleCredentials;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Requirement: Send notification on successful login.
 */
public class FCMHelper {

    private static final String PROJECT_ID = "foodpandaandroid";
    private static final String FCM_URL = "https://fcm.googleapis.com/v1/projects/" + PROJECT_ID + "/messages:send";
    private static String cachedToken = null;
    private static long expiryTime = 0;

    public static void sendNotification(Context context, String receiverToken, String title, String body) {
        if (receiverToken == null || receiverToken.isEmpty()) return;

        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                String token = getAccessToken(context);
                executeApiCall(context, token, receiverToken, title, body);
            } catch (Exception e) {
                Log.e("FCM_HELPER", "Error sending notification: " + e.getMessage());
            }
        });
    }

    private static String getAccessToken(Context context) throws Exception {
        if (cachedToken != null && System.currentTimeMillis() < expiryTime) {
            return cachedToken;
        }

        InputStream is = context.getResources().openRawResource(R.raw.service_account);
        GoogleCredentials credentials = GoogleCredentials.fromStream(is)
                .createScoped(Collections.singletonList("https://www.googleapis.com/auth/firebase.messaging"));

        credentials.refreshIfExpired();
        cachedToken = credentials.getAccessToken().getTokenValue();
        expiryTime = System.currentTimeMillis() + 3500000;

        return cachedToken;
    }

    private static void executeApiCall(Context context, String accessToken, String receiverToken, String title, String body) {
        RequestQueue queue = Volley.newRequestQueue(context);
        try {
            JSONObject notification = new JSONObject().put("title", title).put("body", body);
            JSONObject message = new JSONObject().put("token", receiverToken).put("notification", notification);
            JSONObject payload = new JSONObject().put("message", message);

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, FCM_URL, payload,
                    null, error -> Log.e("FCM", "Error: " + error.toString())) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Authorization", "Bearer " + accessToken);
                    headers.put("Content-Type", "application/json");
                    return headers;
                }
            };
            queue.add(request);
        } catch (JSONException e) { e.printStackTrace(); }
    }
}